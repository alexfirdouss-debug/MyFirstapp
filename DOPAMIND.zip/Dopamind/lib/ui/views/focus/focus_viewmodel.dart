import 'package:stacked/stacked.dart';

class FocusViewModel extends BaseViewModel {
  // TODO: Add timer logic, session management, etc.
}
