import 'package:stacked/stacked.dart';

class GoalsViewModel extends BaseViewModel {
  // TODO: Add goal management logic
}
