import 'package:stacked/stacked.dart';

class MusicViewModel extends BaseViewModel {
  // TODO: Add audio player logic
}
