import 'package:stacked/stacked.dart';

class PersonalizationViewModel extends BaseViewModel {
  // TODO: Add logic to handle questionnaire answers and save to Firestore
}
