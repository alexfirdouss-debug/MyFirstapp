import 'package:stacked/stacked.dart';

class LoginViewModel extends BaseViewModel {
  // TODO: Add login and signup logic here
}
