import 'package:stacked/stacked.dart';

class PlannerViewModel extends BaseViewModel {
  // TODO: Add task and habit tracking logic
}
