import 'package:flutter/material.dart';

const Color kcPrimaryColor = Color(0xFF9147FF); // Lilac
const Color kcSecondaryColor = Color(0xFF3D99E5); // Blue
const Color kcGlowColor = Color(0xFF42F5B4); // Green Glow
const Color kcBackgroundColor = Color(0xFF0D0D1A);
const Color kcCardColor = Color(0x1AFFFFFF); // Glassmorphism card color
