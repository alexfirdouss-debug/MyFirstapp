const String ksAppName = 'Dopamind';
